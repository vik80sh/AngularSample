import { MyServiceService } from './../../my-service.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-book-preview',
  templateUrl: './book-preview.component.html',
  styleUrls: ['./book-preview.component.css']
})
export class BookPreviewComponent implements OnInit {

  book;
  id:string=''
  flag:boolean=false;
  message:string="read more"
  constructor(private myService : MyServiceService ,
  private activateRoute:ActivatedRoute) { 
    
  }
  
  ngOnInit() {
    this.id=this.activateRoute.snapshot.params['id'];
    console.log("Id   =  ",this.id)
    this.myService.entireData().subscribe((data) => {
      this.book = data.find(x => x._id === this.id);
    });
    
    console.log("Books    =  ",this.book)
    
  }
  changeFlag(){
    console.log("Clicked ")
    if(this.flag){
        this.flag = false;
        this.message="read more"
    }else{
      this.flag=true;
      this.message="read less"
    }
    console.log("Hello  ", this.flag)
  }
  
}
