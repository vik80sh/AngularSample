import { Router } from '@angular/router';
import { MyServiceService } from './../my-service.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book-shop',
  templateUrl: './book-shop.component.html',
  styleUrls: ['./book-shop.component.css']
})
export class BookShopComponent implements OnInit {

  
  name : string= "";
  booksList:any=""
  constructor(private myService : MyServiceService , private router: Router ) { 
    this.myService.getName()
    .subscribe(
      data => {
          this.name= data.toString(); 
        },
      error => this.router.navigate(['/signin'])
    );
  }

  ngOnInit() {
  }
  home(){
    this.router.navigate(['/shop'])
  }
}
