
import { HttpClient, HttpParams } from '@angular/common/http';

import { Injectable } from '@angular/core';

@Injectable()
export class MyServiceService {

  booksData:any=[];
  constructor(private http: HttpClient) { 
   }
  entireData () {
    return  this.http.get('http://localhost:4000/books/bookslist');
  }
  submitRegister(userData:any){
    return this.http.post('http://localhost:4000/users/register', userData,{
      observe:'body'
    });
  }

  login(email,password){
    const body={
      email:email,
      password : password
    }
    return this.http.post('http://localhost:4000/users/login', body,{
      observe:'body'
    });
  }
  getName() {
    return this.http.get('http://localhost:4000/users/username', {
      observe: 'body',
      params: new HttpParams().append('token', localStorage.getItem('token'))
    });
  }
}
